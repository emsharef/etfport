FORMAL SOURCE SNAPSHOT FOR MANUSCRIPT2

The accompanying FORMAL_SOURCE_GUIDE.md maps article results to source files.
Standalone contains mathematical statements; Novel contains proof modules;
Upstream contains the explicit hypotheses for cited external mathematics.
The conditional results remain conditional on those hypotheses.

With the pinned Lean toolchain and dependencies installed, run in lean/:
  lake build Audit
This builds the formal source and checks project declarations for forbidden
axiom dependencies. Dependencies are pinned in lake-manifest.json; Mathlib
and its compiled cache are not bundled. Restoring them requires network access.
No public archive or DOI is asserted for this local snapshot.
